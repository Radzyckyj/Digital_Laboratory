# Digital_Laboratory
It contains basic VHDL projects based on "A - Digital Laboratory" USP course.

